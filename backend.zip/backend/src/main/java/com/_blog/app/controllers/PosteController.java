package com._blog.app.controllers;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com._blog.app.dtos.CommentPosteRequest;
import com._blog.app.dtos.PosteCreationRequest;
import com._blog.app.dtos.PosteUpdateRequest;
import com._blog.app.entities.UserAccount;
import com._blog.app.model.JwtUserPrincipal;
import com._blog.app.service.PostesService;
import com._blog.app.shared.GlobalResponse;
import com._blog.app.utils.UserUtils;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/post")

public class PosteController {

    @Autowired
    private PostesService postesService;

    @Autowired
    private UserUtils userUtils;

    @GetMapping
    public ResponseEntity<GlobalResponse<?>> allPost() {
        JwtUserPrincipal principal = (JwtUserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UserAccount currentUser = userUtils.findUserById(principal.getId());
        return new ResponseEntity<>(new GlobalResponse<>(postesService.homePostes(currentUser)),
                HttpStatus.CREATED);
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<GlobalResponse<?>> creatPoste(@RequestPart("data") @Valid PosteCreationRequest posteRequest,
            @RequestPart(value = "file", required = false) List<MultipartFile> file) {
        JwtUserPrincipal principal = (JwtUserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UserAccount currentUser = userUtils.findUserById(principal.getId());

        return new ResponseEntity<>(new GlobalResponse<>(postesService.creatPoste(posteRequest, currentUser, file)), HttpStatus.CREATED);
    }

    @DeleteMapping("/{postId}")
    public ResponseEntity<GlobalResponse<?>> deletPost(@PathVariable UUID postId) {
        JwtUserPrincipal principal = UserUtils.getPrincipal();
        UserAccount currentUser = userUtils.findUserById(principal.getId());
        postesService.deletPost(postId, currentUser);
        return new ResponseEntity<>(new GlobalResponse<>("Deleted !"), HttpStatus.OK);
    }

    @GetMapping("/{postId}")
    public ResponseEntity<GlobalResponse<?>> getPost(@PathVariable UUID postId) {
        JwtUserPrincipal principal = (JwtUserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UserAccount currentUser = userUtils.findUserById(principal.getId());
        return new ResponseEntity<>(new GlobalResponse<>(postesService.getPostes(currentUser, postId)),
                HttpStatus.CREATED);
    }

    @PatchMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<GlobalResponse<?>> updatePost(
            @RequestPart("data") @Valid PosteUpdateRequest posteUpdateRequest,
            @RequestPart(value = "file", required = false) List<MultipartFile> file) {
        JwtUserPrincipal principal = UserUtils.getPrincipal();
        UserAccount currentUser = userUtils.findUserById(principal.getId());
        return new ResponseEntity<>(new GlobalResponse<>(postesService.updatePost(posteUpdateRequest, file, currentUser)), HttpStatus.OK);
    }

    @PostMapping("/like/{postId}")
    public ResponseEntity<GlobalResponse<?>> likePost(@PathVariable UUID postId) {
        JwtUserPrincipal principal = UserUtils.getPrincipal();
        UserAccount currentUser = userUtils.findUserById(principal.getId());
        String toggelLike = postesService.likePost(postId, currentUser);
        return new ResponseEntity<>(new GlobalResponse<>(toggelLike), HttpStatus.OK);
    }

    @GetMapping("/comment/{postId}")
    public ResponseEntity<GlobalResponse<?>> getComment(@PathVariable UUID postId) {
        JwtUserPrincipal principal = UserUtils.getPrincipal();
        UserAccount currentUser = userUtils.findUserById(principal.getId());
        return new ResponseEntity<>(new GlobalResponse<>(postesService.getComment(postId, currentUser)), HttpStatus.OK);
    }

    @PostMapping("/comment")
    public ResponseEntity<GlobalResponse<?>> commentPost(@RequestBody @Valid CommentPosteRequest commentPosteRequest) {
        JwtUserPrincipal principal = UserUtils.getPrincipal();
        UserAccount currentUser = userUtils.findUserById(principal.getId());
        return new ResponseEntity<>(new GlobalResponse<>(postesService.commentPost(commentPosteRequest, currentUser)), HttpStatus.OK);
    }

    @DeleteMapping("/comment/{commentId}")
    public ResponseEntity<GlobalResponse<?>> deletComment(@PathVariable UUID commentId) {
        JwtUserPrincipal principal = UserUtils.getPrincipal();
        UserAccount currentUser = userUtils.findUserById(principal.getId());
        postesService.deletComment(commentId, currentUser);
        return new ResponseEntity<>(new GlobalResponse<>("Comment deleted !"), HttpStatus.OK);
    }

}
