package com._blog.app.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;

import com._blog.app.entities.Postes;
import com._blog.app.entities.UserAccount;

import jakarta.persistence.LockModeType;

public interface PosteRepo extends JpaRepository<Postes, UUID> {

    List<Postes> findAllByUser(UserAccount user);

    @EntityGraph(attributePaths = {"user"})
    List<Postes> findByUserIn(List<UserAccount> users);

    long countByUserId(UUID userId);

    @Override
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    Optional<Postes> findById(UUID postId);

    long countByHideTrue();

    List<Postes> findAllByHideTrue();
}
